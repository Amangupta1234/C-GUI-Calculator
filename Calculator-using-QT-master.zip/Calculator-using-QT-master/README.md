# Calculator-using-QT

C++ GUI Calculator app

The project includes working with widgets in many ways, setting up an interface, stylesheets, casting, regular expressions and much more.

<div style="align:center">
  <img src ="/result.jpg"/>
</div>

## Conclusion:
> I hope this project can help others find their way into the exciting world of GUI applications using C++!

For more projects, follow me on github [Kunal Yelne](https://github.com/kunalyelne):+1:  
Thankyou :heart:

## Credits
[Kunal Yelne](https://github.com/kunalyelne)  
3rd Year,CSE Department.  
[Indian Institute of Information Technology Nagpur.](https://github.com/iiit-nagpur)
